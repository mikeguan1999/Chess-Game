open OUnit2
open Game
open State
open Command



let make_move_test 
    (name: string)
    (piece: Game.piece)
    (move: int * int)
    (valid: bool): test =
  name >:: (fun _ -> assert_equal (valid) (Game.valid_move piece move) 
               ~printer: string_of_bool)


let game_tests = [
  make_move_test "pawn forward" Game.white_pawn (1,0) true;
  make_move_test "pawn forward" Game.black_pawn (-1,0) true;
  make_move_test "pawn invalid" Game.white_pawn (2,1) false;
  make_move_test "pawn invalid2" Game.white_pawn (1,2) false;

  make_move_test "bishop one space" Game.white_bishop (1,1) true;
  make_move_test "bishop multiple spaces" Game.white_bishop (3,3) true;
  make_move_test "bishop multiple spaces" Game.white_bishop (3,-3) true;
  make_move_test "bishop multiple spaces" Game.black_bishop (-5,5) true;
  make_move_test "bishop invalid" Game.white_bishop (0,0) false;


]

let state_tests = []

let command_tests = []



let tests = List.flatten [game_tests; state_tests; command_tests]

let suite = "search test suite" >::: tests

let _ = run_test_tt_main suite