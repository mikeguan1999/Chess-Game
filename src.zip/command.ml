type command=
  |Move of int*int*int*int
  |Resign
  |Quit
  |Draw

exception Empty
exception Malformed

let rec parse_command = function
  |[]->raise Empty
  |""::t->parse_command t
  |"move"::t-> let lst = List.map int_of_string t in 
    Move (List.nth lst 0, List.nth lst 1, List.nth lst 2, 
          List.nth lst 3)
  |"resign"::_-> Resign
  |"quit"::_->Quit
  |"draw"::_->Draw
  |_->raise Malformed

let parse (str:string):command=
  let command_list = (String.split_on_char ' ' str) in
  parse_command command_list
