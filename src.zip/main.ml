open State
open Command

let game_state = State.init_state

let rec run command = exit 0

let end_game (state:State.t)=
  print_endline "\nGame has ended. Final board looks like...\n";
  print_endline (state|>State.to_string);
  ()

let rec run_game (state:State.t)=
  print_string("\n");
  print_endline (state|>State.to_string); 
  print_endline "\nPlease enter your next command. A move command should be in the form of move [starting row] [starting column] [ending row] [ending column].\n";
  print_string  "> ";
  let user_input=read_line () in
  try
    let parsed_input=Command.parse user_input in
    match parsed_input with
    | Move (a,b,c,d) -> begin
        match State.move state (a,b) (c,d) with 
        | Legal m -> run_game m
        | Illegal -> print_endline "Invalid movement. Please enter a new command.";
          run_game state
      end
    | Resign -> end_game state
    | Quit -> end_game state
    | Draw -> end_game state
  with
  |Empty -> print_endline "Empty input. Please enter something into the command.";
    run_game state
  |Malformed -> print_endline "Invalid input. Please enter a valid command.";
    run_game state


let play_game (file: string)=
  (*let json=Yojson.Basic.from_file file in*)
  let state=game_state in
  run_game state

let main () =
  ANSITerminal.(print_string [red]
                  "\n\nWelcome to the board game engine.\n");
  print_endline "Please enter the name of the game file you want to load.\n";
  print_string  "> ";
  (*match read_line () with
    | exception End_of_file -> ()
    | file_name -> *)play_game (*file_name*) ""

let _ = main()
