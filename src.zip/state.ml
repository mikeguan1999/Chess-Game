open Game

type t = {
  board: Game.piece option array array;
  mutable turn: bool
}

let place_pieces board = 
  board.(0).(0) <- Some Game.white_rook;
  board.(0).(7) <- Some Game.white_rook;
  board.(0).(2) <- Some Game.white_bishop;
  board.(0).(5) <- Some Game.white_bishop;
  board.(0).(1) <- Some Game.white_knight;
  board.(0).(6) <- Some Game.white_knight;
  board.(0).(3) <- Some Game.white_queen;
  board.(0).(4) <- Some Game.white_king;
  board.(7).(0) <- Some Game.black_rook;
  board.(7).(7) <- Some Game.black_rook;
  board.(7).(2) <- Some Game.black_bishop;
  board.(7).(5) <- Some Game.black_bishop;
  board.(7).(1) <- Some Game.black_knight;
  board.(7).(6) <- Some Game.black_knight;
  board.(7).(3) <- Some Game.black_queen;
  board.(7).(4) <- Some Game.black_king;
  for i = 0 to fst Game.board-1 do 
    board.(1).(i) <- Some Game.white_pawn;
    board.(6).(i) <- Some Game.black_pawn
  done;
  board

let get_turn state = !state.turn

let init_state =
  let board = Array.make_matrix (fst Game.board) (snd Game.board) None in
  let x = place_pieces board in 
  {board = x; turn = true}

let current_board t = 
  t.board

type result = Legal of t|Illegal

exception Invalid_square of (int * int)

let get t coord =
  let piece = t.(fst coord).(snd coord) in
  piece

let place t first second piece = 
  t.(fst first).(snd first) <- None;
  t.(fst second).(snd second) <- Some piece; t


let vector ((a,b): int*int) ((c,d): int*int) = (c-a,d-b) 

let move t current final =
  try 
    match get t.board current with 
    |None -> Illegal
    |Some p -> 
      if Game.valid_move p (vector current final) && Game.piece_color p = t.turn
      then Legal {board = place t.board current final p; turn = not (t.turn)}
      else Illegal
  with Invalid_argument (e) -> Illegal

let to_string (state:t) =
  let matrix = state.board in 
  let string = ref " " in
  for j = 0 to 7 do 
    string := !string ^ "  " ^ string_of_int j ^ " "
  done;
  string := !string ^ "\n  -";
  for j = 0 to 7 do 
    string := !string ^ "----"
  done;
  string := !string ^ "\n ";
  for i = 0 to 7 do 
    string:= !string ^ (string_of_int(i)) ^ "|";
    for j = 0 to 7 do 
      match matrix.(i).(j) with 
      | None -> string := !string ^ "   |"
      | Some p -> string := !string ^ (Game.piece_name p) ^ "|"
    done;
    string := !string ^ "\n  -";
    for j = 0 to 7 do 
      string := !string ^ "----"
    done;
    string := !string ^ "\n ";
  done;
  !string
