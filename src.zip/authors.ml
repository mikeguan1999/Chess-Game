(* TODO: set the value below.  There should be one element
   of the list per author of the submission.  Order does
   not matter. *)
let hours_worked = [9; 9; 9]
